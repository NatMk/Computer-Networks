import java.util.List;

/*
 * This is interface for graph to find the shortest path between two routers.
 */

public interface Graph<T> 
{

	public void addVertex (T t);
	
	public void addEdge(T t1, T t2, int weight);
	
	public List<T> neighbours(T t);
	
	public List<T> shortestPath(T t1, T t2);
	
	public int getDist(T t1, T t2);
	
}
