import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.*;
/*
 *  This class represents server.
 */
public class Server 
{

	private static Graph<String> graph; // Graph instance to find the shortest path.

	public static void main(String[] args) // Main method to run the server.
	{ 

		final List<ClientListener> listeners = new ArrayList<>(); // List to store all listeners, more precisely: all routers.

		try (ServerSocket serverSocket = new ServerSocket(2222)) // Run server on localhost, port 2222 (port can be changed).
		{
			while (true) 
			{
				System.out.println("Listening...");
				Socket clientSocket = serverSocket.accept(); // Listen for the clients...
				System.out.println("Accepted client!");

				ClientListener listener = new ClientListener(clientSocket, listeners); // Create listener for the accepted client.
				listeners.add(listener); // Add this listener to the list.
				new Thread(listener).start(); // Start client listener in a separate thread.
			}
		 } 
		 catch (IOException e) 
		 {
			System.out.println("Server stopped.");
		 }

	}

	/*
	 *  This class is intended to listen incoming request from the clients.
	 */
	static class ClientListener implements Runnable 
	{

		boolean run = true; // Indicates whether listener should listen to incoming segments.

		Socket socket; // Socket to create input/output streams. This variable is needed to have an option to close socket.

		ObjectOutputStream oos; // Output stream to write segments.

		List<ClientListener> listeners; // List with all other listeners.

		String name; // Name of this router/listener.

		String checksum; // Checksum to identify router every-time when a segment is accepted.

		/*
		 * Assigning values to socket and listeners
		 */
		public ClientListener(Socket socket, List<ClientListener> listeners) 
		{
			this.socket = socket;
			this.listeners = listeners;
		}

		@Override
		public void run() 
		{
			try (ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream())) // Instantiate output stream to write messages. 
			{ 
				
				this.oos = oos;
				try (ObjectInputStream ois = new ObjectInputStream(socket.getInputStream())) // Instantiate input stream to read messages.
				{ 
					
					while (run) // While listener listens incoming segments.
					{ 
						Segment seg = (Segment)ois.readObject(); // Get segment.

					   switch (seg.header) // Check header.
					   { 
						 case "SYN":
							seg.header = "ACK&SYN";
							checksum = seg.checksum;
							sendSegment(oos, seg);
							break;
							
						 case "ACK": // Second step of 3 way handshake.
							if (checksum == null) 
							{
								seg.header = "RST"; // Drop connection (maybe dangerous) b/c checksum is not set yet, but acknowledgement is received.
								dropSegment(seg);
								sendSegment(oos, seg);
							} 
							else 
							{
								System.out.println("Name for " + seg.msg);
								name = seg.msg; // Set name.
								System.out.println("Second step of 3 way handshake from " + name);
							}
							break;
							
						 case "FIN": // When message is successfully received by the target agent.
							System.out.println("Server: success");
							break;
							
						case "URG": // Just a message (urgent to make mission successful).
							if (seg.checksum.equals(checksum)) 
							{
								System.out.println("Server: URGENT message: current router: " + seg.curRouter);
								for (ClientListener listener: listeners) 
								{
									if (listener.name.equals(seg.curRouter)) 
									{
										System.out.println("Server: URGENT message: send to: " + listener.name);
										sendSegment(listener.oos, seg);
										break;
									}
								}
							} 
							else  // If the checksum is wrong. 
							{
								System.out.println("Server: Wrong checksum! Drop connection.");
								dropSegment(seg);
								sendSegment(oos, seg);
							}
							break;
						case "SP": // If request for shortest path is received.
							System.out.println("Server: Request for Shortest Path");
							
							if (seg.checksum.equals(checksum)) // Always check checksum.
							{ 
								String from = getRouterByAgent(seg.from);
								String to = getRouterByAgent(seg.to);
								List<String> sp = initGraph().shortestPath(from, to);
								String [] path = sp.toArray(new String[sp.size()]);
								seg.path = path;
								sendSegment(oos, seg);
							 } 
							 else 
							 {
								System.out.println("Server: Wrong checksum! Drop connection: ");
								dropSegment(seg);
								sendSegment(oos, seg);
							 }
							break;
						}
					}
				} catch (IOException e) 
				  {
					System.out.println("Client " + name + " lost");
				  } 
				  catch (ClassNotFoundException e){}
			}     catch (IOException e1) {}

		}

		private void sendSegment(ObjectOutputStream oos, Segment seg) throws IOException 
		{
			oos.writeObject(seg);
			oos.reset();
			oos.flush();
		}
		
		private void dropSegment(Segment seg) 
		{
			seg.header = "RST"; // Drop connection, may be danger.
			seg.msg = null;
			seg.path = null;
			seg.from = null;
			seg.to = null;
		}

	}
	
	// Server 'knows' which router is the nearest to the given agent.
	private static String getRouterByAgent(String agent) 
	{
		if (agent.equals("Ann")) 
		{
			return "A";
		}
		else if (agent.equals("Jan"))
		{
			return "F";
		} 
		else if (agent.equals("Chan")) 
		{
			return "E";
		}
		return "Unknown";
	}

	// Build graph according to the map in specs.
	private static Graph<String> initGraph() 
	{
		if (graph == null) 
		{
			graph = new MapMission<>(8);
			graph.addVertex("A");
			graph.addVertex("B");
			graph.addVertex("C");
			graph.addVertex("D");
			graph.addVertex("E");
			graph.addVertex("F");
			graph.addVertex("G");
			graph.addVertex("L");
			graph.addEdge("B", "A", 4);
			graph.addEdge("L", "B", 5);
			graph.addEdge("L", "F", 5);
			graph.addEdge("F", "D", 6);
			graph.addEdge("D", "G", 10);
			graph.addEdge("G", "E", 5);
			graph.addEdge("E", "A", 7);		
			graph.addEdge("B", "C", 6);
			graph.addEdge("A", "C", 3);
			graph.addEdge("L", "D", 9);
			graph.addEdge("C", "D", 11);
		}
		return graph;
	}

}

