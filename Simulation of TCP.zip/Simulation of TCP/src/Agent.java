
import java.io.File;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class Agent {

	static final Random RAND = new Random(); // Random object to generate random number for checksum.

	static String checksum; // To simulate checksum.

	public static void main(String...args) // Main method to run Agent.
	{ 

		String from = args[0]; // Get the name of Agent (more precisely, name of folder with .txt files).

		Path dir = Paths.get(from); // Get the path to that folder (directory with .txt files).
		
		try 
		{
			Socket clientSocket = new Socket(InetAddress.getByName("localhost"), 2222); // Create socket with localhost
			// and port 2222. Note: you can use other port and other host, but in this case you should change them 
			// in Server and Client as well.
			
			ObjectOutputStream oos = new ObjectOutputStream(clientSocket.getOutputStream()); // Create output stream
			// from socket to write messages.

			checksum = String.valueOf(RAND.nextInt(1_000_000)); // Use random integer for checksum.
			Segment seg = new Segment("SYN", null, null, null, from, null, checksum); // Pass checksum.
			sendSegment(oos, seg); // First step in 3 way handshake.
			System.out.println("First step of 3 way handshake: " + from + " is sending checksum to server: " + checksum);

			ObjectInputStream ois = new ObjectInputStream(clientSocket.getInputStream()); // Create input stream from
			// socket to read messages.
			
			new Thread(new ServerListener(args[0], ois, oos)).start(); // Run listener in a separate thread and separate
			// static class to read responses separately.

			System.out.println(from +" is ready for conversation...");
			
			try (Scanner sc = new Scanner(System.in)) // Create scanner to read .txt files.
			{ 
				sc.nextLine(); // Wait until the user clicks on 'Enter' to start conversation.
				try 
				{
					File[] files = dir.toFile().listFiles(); // Get all .txt files from directory.
					for (File f: files)  // Loop through the files.
					{
						String to = f.getName().replaceAll(from + "-_", "").replaceAll(".txt", ""); // Get the name of the target agent.		
						System.out.println("From : " + from + ", To: " + to);

						List<String> lines = Files.readAllLines(f.toPath()); // Read all lines from .txt file.
						for (String line: lines) // Loop through the lines.
						{ 
							seg.header = "SP"; // Add header SP: that means shortest path request, i.e. current agent needs
							// the shortest path between him and target agent.
							
							seg.from = from; // Add from to segment to be sent.
							seg.to = to; // Add to to segment to be sent.
							seg.msg = line; // Add message (just a line, i.e. portion of the conversation).
							sendSegment(oos, seg); // Sent segment
							System.out.println("Request for shortest path from  " + from + " to " + to + " has been sent");
							Thread.sleep(1000); // Use 1 second to make sure the previous message is sent before the next one.
						}
					}
				} catch (Exception e){}
				  sc.nextLine(); // Wait until the user clicks on 'Enter' to finish the mission.
			}
			System.out.println("Successful mission.");
			clientSocket.close();
		} catch (IOException e) 
		  {
			e.printStackTrace();
		  }

	}

	// This is static class to listen to incoming messages from other routers through the server and send the responses.
	static class ServerListener implements Runnable 
	{

		boolean run = true; // Indicates whether this listener should exist.

		ObjectInputStream ois; // Input stream to read messages.

		ObjectOutputStream oos; // Output stream to write responses.

		String name; // Name of this agent.

		public ServerListener(String name, ObjectInputStream ois, ObjectOutputStream oos)
		{
			this.name = name;
			this.ois = ois;
			this.oos = oos;
		}

		@Override
		public void run() 
		{

			while (run) 
			{
				try 
				{
					Segment seg = (Segment)ois.readObject(); // Get the incoming segment.
					switch (seg.header) { // Check header.
					case "ACK&SYN": // Last step in 3 way handshake, change header to ACK.
						seg.header = "ACK";
						seg.msg = name;
						sendSegment(oos, seg);
						System.out.println("Last step of 3 way handshake (agent" + name + ": ACK is sending...");
						break;
						
					case "URG": // Urgent request, i.e. our message from conversation.
						System.out.println("Message received by agent " + name + ": " + seg.msg);
						break;
						
					case "SP":
						System.out.println(name + " received SP from server: " + Arrays.toString(seg.path));
						seg.curRouter = seg.nextRouter();
						System.out.println("Current router: " + seg.curRouter);
						seg.header = "URG";
						sendSegment(oos, seg);
						break;
						
					case "RST": // Reset request.
						run = false; // Drop connection.
						break;
					}
				} catch (ClassNotFoundException | IOException e) 
				  {
					run = false;
				  }
			} // while
		} // run method
	} // static class

	// This method accepts output stream and segment to be sent.
	private static void sendSegment(ObjectOutputStream oos, Segment seg) throws IOException
	{
		seg.checksum = checksum; // Always update checksum to make sure the server can identify sender.
		oos.writeObject(seg);
		try 
		{
			oos.reset();
		} catch (Exception exc){}
		oos.flush(); // clear the output stream
	}
}
