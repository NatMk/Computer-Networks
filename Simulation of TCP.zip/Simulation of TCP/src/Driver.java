/*
 * This class is intended to run all required routers.
 */
public class Driver 
{

	public static void main(String[] args) throws InterruptedException 
	{
		// Run routers A through L.
		Client.main("A");
		System.out.println("Router A is running...");
		Client.main("B");
		System.out.println("Router B is running...");
		Client.main("C");
		System.out.println("Router C is running...");
		Client.main("D");
		System.out.println("Router D is running...");
		Client.main("E");
		System.out.println("Router E is running...");
		Client.main("F");
		System.out.println("Router F is running...");
		Client.main("G");
		System.out.println("Router G is running...");
		Client.main("L");
		System.out.println("Router L is running...");

		System.out.println("done");
	} // main

} // class
