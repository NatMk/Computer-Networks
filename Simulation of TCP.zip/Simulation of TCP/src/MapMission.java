import java.util.*;
/*
 * This class encapsulates graph to find the shortest path between 2 routers in the map.
 */

public class MapMission<T> implements Graph<T>
{
	
	private List<T> vertices; // Stores all the vertices of the Graph.
	
	private int[][] matrix; // Stores adjacency matrix of the distance between two given vertices.
	
	public MapMission(int size) 
	{
		vertices = new ArrayList<>();
		matrix = new int[size][size];
	}

	@Override
	public void addVertex(T t) // Method to add vertex.
	{ 
		vertices.add(t);		
	}

	@Override
	public void addEdge(T t1, T t2, int weight) // Add edge: weight between two vertices.
	{
		int i = vertices.indexOf(t1);
		int j = vertices.indexOf(t2);
		matrix[i][j] = weight;
		matrix[j][i] = weight;
	}

	@Override
	public List<T> neighbours(T t) // Determines all the neighboring (adjacent routers) of the given router.
	{ 
		List<T> neighs = new ArrayList<>();
		int j = vertices.indexOf(t);
		for (T n: vertices) {
			int i = vertices.indexOf(n);
			
			if (matrix[i][j] != 0) { // If there is path between j and i, then weight cannot be 0.
				neighs.add(n);
			}
		}
		
		// sort neighbors to place the neighbor with the shortest distance
		// at the first place (to make Dijkstra algorithm more efficient).
		Collections.sort(neighs, (n1, n2) -> Integer.compare(getDist(n1, t), getDist(n2, t)));
		return neighs;
	}

	/*
	 * This method uses Dijkstra's algorithm 
	 */
	@Override
	public List<T> shortestPath(T t1, T t2) 
	{
		List<T> path = new ArrayList<>(); // Empty list to store shortest path.
		Map<T, Boolean> visited = new HashMap<>(); // Map to store visited vertices (true if visited, otherwise false).
		Map<T, Integer> dists = new HashMap<>(); // Map to store vertices as keys and current shortest distances as values.
		Map<T, T> prevs = new HashMap<>(); // Map to store the previous vertex in the path. It's needed in order to allocate the path
		// between t2 and t1. If we iterate over the previous vertices in this map starting from t2, then the last
		// previous vertex will be t1, consequently the required shortest path is found.
		
		Queue<T> q =  new LinkedList<>(); // Create empty queue to add/poll vertices.
		for (T v: vertices) // Loop through the vertices.
		{ 
			visited.put(v, false); // Assign false to all vertices since they are all unvisited at this time (initially).
			dists.put(v, Integer.MAX_VALUE); // Assign max value to all vertices since we don't know distances at this time (initially).
		}
		visited.put(t1, true); // Update visited value for starting vertex.
		dists.put(t1, 0); // Update distance value for starting vertex (distance from t1 to t1 is obvious 0).
		q.add(t1); // Add starting vertex to the queue.
		while(!q.isEmpty()) // While queue contains at least 1 vertex.
		{ 
			T cur = q.poll(); // Get the vertex from the head of the queue.
			visited.put(cur, true); // Visit this vertex.
			
			for (T n: neighbours(cur)) // Iterate over all the neighbors
			{ 
				int dist = dists.get(cur) + getDist(n, cur); // Calculate the new distance from neighbour to the cur.
				if (dist < dists.get(n)) // If this distance is less than the previously stored.
				{ 
					dists.put(n, dist); // Update distance.
					prevs.put(n, cur); // Update previous vertext in the path.
				}
				if (!visited.get(n)) // If neighbor is not visited yet.
				{
					q.add(n); // Add it to the queue.
				}
			}
		}
		
		// Iterate over previous vertices starting from t2 to find the shortest path between t2 and t1.
		for (T next = t2; next != null; next = prevs.get(next)) 
		{
			path.add(next); // Add next to the list.
		}
		Collections.reverse(path); // Finally, reverse path to have t1 at the first place.
		return path;
	}

	// Method to get the distance between two given vertices. Adjacency matrix is used.
	@Override
	public int getDist(T t1, T t2) 
	{
		int i = vertices.indexOf(t1);
		int j = vertices.indexOf(t2);
		return matrix[i][j];
	}

}
