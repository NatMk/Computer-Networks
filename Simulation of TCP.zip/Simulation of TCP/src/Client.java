import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.util.Random;

/*
 * This class encapsulates router and establishes connection with the server.
 */

public class Client 
{
	public static void main(String...args) // Main method to run router.
	{ 
		try 
		{
			Socket clientSocket = new Socket(InetAddress.getByName("localhost"), 2222); // Router runs on local-host
			// and port 2222 (default port, you can use any other non-busy valid port and different host).

			new Thread(new ServerListener(args[0], clientSocket)).start(); // Start listener in a separate thread
			// to listen for the incoming segments and write responses.
		} 
		catch (IOException e) {}

	}

	/* 
	 * This class is intended to listen incoming requests and write appropriate responses depending on the headers.
	 */
	static class ServerListener implements Runnable 
	{
		final Random RAND = new Random(); // To generate random numbers for checksum.

		boolean run = true; // Indicates whether listener should run.

		Socket clientSocket; // Socket to connect to the server.

		String name; // Name of router (A, B, C etc.).

		String checksum; // To simulate checksum.

		public ServerListener(String name, Socket clientSocket) 
		{
			this.name = name;
			this.clientSocket = clientSocket;
			checksum = String.valueOf(RAND.nextInt(1_000_000)); // Use random integer for checksum.
		}

		@Override
		public void run() 
		{
			try (ObjectOutputStream oos = new ObjectOutputStream(clientSocket.getOutputStream())) // Use try-with-resources
			{ // to instantiate output stream and close it once the router stops working.
				
				Segment seg = new Segment("SYN", null, null, null, name, null, checksum); // Pass checksum.
				sendSegment(oos, seg); // First step in 3 way handshake.
				System.out.println("First step of 3 way handshake: " + name + " is sending checksum to server: " + checksum);
				
				try (ObjectInputStream ois = new ObjectInputStream(clientSocket.getInputStream())) // Use try-with-resources
				{ // to instantiate input stream and close it once the router stops working.
					
					while (run) // While this router listens for the incoming requests.
					{ 
						try {
							seg = (Segment)ois.readObject(); // Get the incoming segment.
							System.out.println("Client " + name);
							
							switch (seg.header) // Check header
							{ 
							case "ACK&SYN": // Last step in 3 way handshake.
								seg.header = "ACK";
								seg.msg = name;
								sendSegment(oos, seg);
								System.out.println("Last step of 3 way handshake (agent" + name + ": ACK is sending...");
								break;
								
							case "URG":
								System.out.println("Router: " + name + " Received: " + seg.msg);
								if (name.equals(seg.path[seg.path.length - 1])) // If this is last router in the shortest path.
								{ 								
									System.out.println("Last router: " + name);
									seg.header = "FIN"; // Finish, message received.
									seg.curRouter = seg.to; // Assign current router as the last router.
									sendSegment(oos, seg);
								} 
								else // If this is just a router in the shortest path (not last one).
								{ 
									System.out.println("current router: " + seg.curRouter);
									seg.curRouter = seg.nextRouter(); // Assign the current router as a next.
									System.out.println("next router: " + seg.curRouter);
									sendSegment(oos, seg); // No change header, just transfer to the next router in the path.
								}
								break;
								
							case "RST": // If request to reset connection is received.
								run = false; // Drop connection.
								break;
							}

						} catch (ClassNotFoundException | IOException e) 
						  {
							run = false; // Stop listening once exception occurred.
						  }

					} // while loop
					System.out.println("Router " + name + " lost");
				}   catch (IOException e1) {}
			}       catch (IOException e2) {}
		} // run method

		// This method accepts output stream and segment to be sent.
		private void sendSegment(ObjectOutputStream oos, Segment seg) throws IOException
		{
			seg.checksum = checksum;
			oos.writeObject(seg);
			oos.reset();
			oos.flush();
		}

	} // Listener class

} // Client class
