import java.io.Serializable;
/*
 *  This class encapsulates segment to be sent over network.
 */
public class Segment implements Serializable 
{
	private static final long serialVersionUID = 1L;

	String from; // Name of sender.
	
	String to; // Name of receiver.
	
	String curRouter; // Name of current router in the shortest path.
	
	String msg; // Message.
	
	String header; // Header (ACK, RST, URG etc.).
	
	String[] path; // Shortest path (contains names of all routers in the path).
	
	private int curIndex; // Stores current index of path.
	
	String checksum; // Stores checksum.
	
	//Method to assign values of header, message and router
	Segment(String header, String from, String to, String curRouter, String msg, String[] path, String checksum) 
	{
		this.header = header;
		this.from = from;
		this.to = to;
		this.curRouter = curRouter;
		this.msg = msg;
		this.path = path;
		this.checksum = checksum;
	}
	
	String nextRouter() // Get the next router in the path.
	{
		return path[curIndex++]; // Increment index.
	}
	
}
